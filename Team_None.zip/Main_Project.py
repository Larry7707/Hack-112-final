
import pygame
import random,string,math


class PygameGame(object):

    """
    a bunch of stuff is left out of this file, but you can check it out in the
     Github repo
    """

    def isKeyPressed(self, key):
        ''' return whether a specific key is being held '''
        return self._keys.get(key, False)

    def __init__(self, width=600, height=400, fps=50, title="112 Pygame Game"):
        self.width = width
        self.height = height
        self.fps = fps
        self.title = title
        pygame.init()

    def run(self):

        clock = pygame.time.Clock()
        screen = pygame.display.set_mode((self.width, self.height))
        # set the title of the window
        pygame.display.set_caption(self.title)

        # stores all the keys currently being held down
        self._keys = dict()

        # call game-specific initialization
        self.init()
        playing = True
        while playing:
            time = clock.tick(self.fps)
            self.timerFired(time)
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.mousePressed(*(event.pos))
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.mouseReleased(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons == (0, 0, 0)):
                    self.mouseMotion(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons[0] == 1):
                    self.mouseDrag(*(event.pos))
                elif event.type == pygame.KEYDOWN:
                    self._keys[event.key] = True
                    self.keyPressed(event.key, event.mod)
                elif event.type == pygame.KEYUP:
                    self._keys[event.key] = False
                    self.keyReleased(event.key, event.mod)
                elif event.type == pygame.QUIT:
                    playing = False
            screen.fill((255, 255, 255))
            self.redrawAll(screen)
            pygame.display.flip()

        pygame.quit()

import pygame, random
from pygame.locals import *

<<<<<<< HEAD

class Dot(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(Dot, self).__init__()
        self.radius = random.randint(5, 20)
        self.x, self.y = x, y
        self.xSpeed = random.randint(-10, 10)
        self.ySpeed = random.randint(-10, 10)
        self.rect = pygame.Rect(x - self.radius, y - self.radius,
                                2 * self.radius, 2 * self.radius)
        self.image = pygame.Surface((2 * self.radius, 2 * self.radius),
                                    pygame.SRCALPHA)  # make it transparent
        self.image = self.image.convert_alpha()
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        pygame.draw.circle(self.image, (r, g, b),
                           (self.radius, self.radius), self.radius)

    def getRect(self):  # GET REKT
        self.rect = pygame.Rect(self.x - self.radius, self.y - self.radius,
                                2 * self.radius, 2 * self.radius)

    def update(self, screenWidth, screenHeight):
        self.x += self.xSpeed
        self.y += self.ySpeed
        if self.x < 0:
            self.x = screenWidth
        elif self.x > screenWidth:
            self. x = 0
        if self.y < 0:
            self.y = screenHeight
        elif self.y > screenHeight:
            self.y = 0
        self.getRect()
=======
class Struct(object): pass

data = Struct()
data.width, data.height=(600,600)
<<<<<<< HEAD
>>>>>>> origin/master
=======
data.moving=True
>>>>>>> origin/master

pygame.init()
screen = pygame.display.set_mode((data.width, data.height))
clock = pygame.time.Clock()


class Character(pygame.sprite.Sprite):
    def __init__(self, data, pX, pY, cPicFilename, scale=1, angle=0):
        super(Character, self).__init__()
        self.cPositionX=pX
        self.cPositionY=pY
        # initialize and adjust the character
        self.character=pygame.image.load(cPicFilename).convert_alpha()    
        self.character=pygame.transform.rotate(self.character, angle)
        (cWidth, cHeight)=self.character.get_size()
        (self.cWidth, self.cHeight)=(int(cWidth*scale), int(cHeight*scale))
        self.image=pygame.transform.scale(self.character, (self.cWidth, self.cHeight))
        self.rect = pygame.Rect(self.cPositionX, self.cPositionY, self.cWidth, self.cWidth)

    def getRect(self):  # GET REKT
        self.rect = pygame.Rect(self.cPositionX, self.cPositionY, self.cWidth, self.cHeight)

    def update(self, x, y):
        if(0 <= self.cPositionX+x <= data.width):
            self.cPositionX += x
        if(0 <= self.cPositionX+x <= data.height):
            self.cPositionY += y
        self.getRect()



class Background(object):
    def __init__(self, data, bPicFilename):
        self.background=pygame.image.load(bPicFilename).convert()
        self.background=pygame.transform.scale(self.background, (data.width, data.height))

    def display(self):
        screen.blit(self.background, (0,0))


background = Background(data, 'pictures/background.jpg')
myCharacter = Character(data, 200, 200, 'pictures/fugu.png', 0.5, 90)
furnitures = Character(data, 300, 300, 'pictures/table.png',0.5)


sprites_move = pygame.sprite.Group()
sprites_unmove = pygame.sprite.Group() 
sprites_move.add(myCharacter)
sprites_unmove.add(furnitures)


while True:
    for event in pygame.event.get():
        (moveX, moveY) = (0, 0)
        if event.type == QUIT:
            exit()
        if event.type == KEYDOWN:
            if event.key == K_LEFT:
                (moveX, moveY) = (-5, 0)
            elif event.key == K_RIGHT:
                (moveX, moveY) = (+5, 0)
            elif event.key == K_UP:
                (moveX, moveY) = (0, -5)
            elif event.key == K_DOWN:
                (moveX, moveY) = (0, +5)

    sprites_move.update(moveX,moveY)
    if(pygame.sprite.collide_rect(myCharacter, furnitures)):
        sprites_move.update(-moveX,-moveY)

    background.display()
    sprites_move.draw(screen)
    sprites_unmove.draw(screen)
    
    


        
    pygame.display.update()






