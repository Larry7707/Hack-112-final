'''
pygamegame.py
created by Lukas Peraza
 for 15-112 F15 Pygame Optional Lecture, 11/11/15

use this code in your term project if you want
- CITE IT
- you can modify it to your liking
  - BUT STILL CITE IT

- you should remove the print calls from any function you aren't using
- you might want to move the pygame.display.flip() to your redrawAll function,
    in case you don't need to update the entire display every frame (then you
    should use pygame.display.update(Rect) instead)
'''
import pygame,random
from instructionMode import *


class PygameGame(object):

    def init(self):
        self.mode = "Main_Screen"


    def mousePressed(self, x, y):
        pass

    def mouseReleased(self, x, y):
        pass

    def mouseMotion(self, x, y):
        pass

    def mouseDrag(self, x, y):
        pass

    def keyPressed(self, keyCode, modifier):
        if keyCode == pygame.K_d:
            self.mode = "gameover" # for test
                    # 1 for explosion, 2 for out of O2, 3 for sense of blame
            self.dieReason = random.randint(0,2)
        elif keyCode == pygame.K_r:
            self.init()


    def keyReleased(self, keyCode, modifier):
        pass

    def timerFired(self, dt):
        pass

    def redrawAll(self, screen):
        if self.mode == "gameover":
            self.drawGameover(screen)


    def drawGameover(self, screen): #draw gameover 
        (width, height) = screen.get_size()
        dieReason = {0:"boom.jpg",1:"noo2.jpg",
                    2:"blame.jpg"}
        picpath = dieReason[self.dieReason]
        self.image = pygame.transform.scale(
                pygame.image.load(picpath).convert(),
            (width, height))
        screen.blit(self.image, (0,0))
        fontsize = 150
        font = pygame.font.SysFont("arial", fontsize,True)
        text = "YOU DIE!"
        screen.blit(font.render(text,True,(255,0,0)),
                    (width/2-fontsize*1.8,height/2-fontsize))
        dieDicription={0:"You are killed by the tube explosion",
                    1:"No oxygen!!!!! No life!!!!!",
                    2:"You are sooooo useless!!"}
        text = dieDicription[self.dieReason]
        fontsize = 20
        font = pygame.font.SysFont("times new roman", fontsize)
        screen.blit(font.render(text,True,(200,0,0)),
                    (width/2-fontsize*4.5,height/2+fontsize))

    def isKeyPressed(self, key):
        ''' return whether a specific key is being held '''
        return self._keys.get(key, False)

    def __init__(self, width=800, height=600, fps=50, title="112 Pygame Game"):
        self.width = width
        self.height = height
        self.fps = fps
        self.title = title
        self.bgColor = (255, 255, 255)
        pygame.init()

    def run(self):

        clock = pygame.time.Clock()
        screen = pygame.display.set_mode((self.width, self.height))
        # set the title of the window
        pygame.display.set_caption(self.title)

        # stores all the keys currently being held down
        self._keys = dict()

        # call game-specific initialization
        self.init()
        playing = True
        while playing:
            time = clock.tick(self.fps)
            self.timerFired(time)
            if self.mode =="instruction":
            # print("step2,pass")
                instructionRun(self,screen)
                # self.mode = instructionRun(self.mode, screen)
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.mousePressed(*(event.pos))
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    self.mouseReleased(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons == (0, 0, 0)):
                    self.mouseMotion(*(event.pos))
                elif (event.type == pygame.MOUSEMOTION and
                      event.buttons[0] == 1):
                    self.mouseDrag(*(event.pos))
                elif event.type == pygame.KEYDOWN:
                    self._keys[event.key] = True
                    self.keyPressed(event.key, event.mod)
                elif event.type == pygame.KEYUP:
                    self._keys[event.key] = False
                    self.keyReleased(event.key, event.mod)
                elif event.type == pygame.QUIT:
                    playing = False
            screen.fill(self.bgColor)
            self.redrawAll(screen)
            pygame.display.flip()
        pygame.quit()


def main():
    game = PygameGame()
    game.run()

if __name__ == '__main__':
    main()
