'''
Game.py

Actually implements the game
Lukas Peraza, 2015 for 15-112 Pygame Lecture
'''
import pygame
from Main_Screen import Character, Background
from pygamegame import PygameGame
from instructionMode import *
from shelfMode import *

########## Main Screen Mode ##########################
def init_MainScreen(self, cPositionX=400, cPositionY=400, scale=0.5, angle=0):
    self.background_path = 'pictures/background.jpg'
    (self.moveX, self.moveY)=(0,0)
    self.collide_arec=0

    self.myCharacter = Character(self, 300, 200, 'pictures/fugu.png',0.3) 
    self.sprites_move = pygame.sprite.Group()
    self.sprites_move.add(self.myCharacter)

    self.furnitures = Character(self, 22, 355, 'pictures/table.png',0.2)
    self.rec1 = Character(self, 70, 350, 'pictures/rectangle.jpg',0.1)
    self.rec2 = Character(self, 130, 330, 'pictures/rectangle.jpg',0.1)
    self.rec3 = Character(self, 193, 340, 'pictures/rectangle.jpg',0.1)
    self.rec4 = Character(self, 250, 330, 'pictures/rectangle.jpg',0.1)
    self.sprites_unmove_back = pygame.sprite.Group() 
    self.sprites_unmove_back.add(self.furnitures)
    self.sprites_unmove_back.add(self.rec1)
    self.sprites_unmove_back.add(self.rec2)
    self.sprites_unmove_back.add(self.rec3)
    self.sprites_unmove_back.add(self.rec4)
    self.cabinet = Character(self, 400, 20, 'pictures/cabinet.png',0.2) ##
    self.sprites_unmove_front = pygame.sprite.Group() 
    self.sprites_unmove_front.add(self.cabinet)#########################
    self.text_font = pygame.font.SysFont("arial", 40)


    self.chatbox=pygame.image.load('pictures/chatbox.png').convert_alpha() 



def keyPressed_MainScreen(self, code, mod):
    if code == pygame.K_LEFT:
        (self.moveX, self.moveY) = (-5, 0)
    elif code == pygame.K_RIGHT:
        (self.moveX, self.moveY) = (+5, 0)
    elif code == pygame.K_UP:
        (self.moveX, self.moveY) = (0, -5)
    elif code == pygame.K_DOWN:
        (self.moveX, self.moveY) = (0, +5)
    elif code == pygame.K_i: # change
        self.mode = "instruction"
        # print(True)
    elif code == pygame.K_s:
        self.mode = "shelf"

def keyReleased_MainScreen(self, code, mod):
    (self.moveX, self.moveY)=(0,0)


def timerFired_MainScreen(self, dt):
    self.sprites_move.update(self.moveX,self.moveY)
    if(pygame.sprite.collide_rect(self.myCharacter, self.furnitures)):
        self.sprites_move.update(-self.moveX,-self.moveY)
    if(pygame.sprite.collide_rect(self.myCharacter, self.rec1)):
        self.collide_arec=1
    elif(pygame.sprite.collide_rect(self.myCharacter, self.rec2)):
        self.collide_arec=2 #
    elif(pygame.sprite.collide_rect(self.myCharacter, self.rec3)):
        self.collide_arec=3
    elif(pygame.sprite.collide_rect(self.myCharacter, self.rec4)):
        self.collide_arec=4
    elif(pygame.sprite.collide_rect(self.myCharacter, self.cabinet)):
        self.collide_arec=5
    else: self.collide_arec=0

def keyReleased_SplashScreen(self, code, mod):     ######################## changed from here
    if code == pygame.K_p:
        init_MainScreen(self)
        self.mode='Main_Screen'    


############### Main Game Function #############################
class Game(PygameGame):
    def init(self):
        super().init()
        self.mode='splash'                          ###################### changed from here
        self.background_path='pictures/splash.png'
        # init_MainScreen(self)
        

    def keyPressed(self, code, mod):
        super().keyPressed(code,mod)
        if(self.mode=='Main_Screen'):
            keyPressed_MainScreen(self, code, mod)
    
    def keyReleased(self, code, mod):
        if(self.mode=='Main_Screen'):
            keyReleased_MainScreen(self, code, mod)
        elif(self.mode=='splash'):
            keyReleased_SplashScreen(self, code, mod)

    def timerFired(self, dt):
        if(self.mode=='Main_Screen'):
            timerFired_MainScreen(self, dt)

    def redrawAll(self, screen):
        
        if self.mode =="gameover": # call father redraw function
            super().redrawAll(screen)
            return
        background = Background(screen, self.width, self.height, 
            self.background_path)
        background.display()
        if self.mode =="instruction":
            # print("step2,pass")
            instructionRun(self,screen)
        if self.mode == "shelf":
            shelfRun(self,screen)
        if(self.mode=='Main_Screen'): 
            self.sprites_unmove_back.draw(screen)
            background.display()
            self.sprites_unmove_front.draw(screen)
            if(self.collide_arec==1):
                screen.blit(self.chatbox, (70, 80))
                text_surface = self.text_font.render('Press i for help', 
                    True, (0, 0, 0))
                screen.blit(text_surface, (100, 150))
            elif(self.collide_arec==2):
                screen.blit(self.chatbox, (150, 80))
                text_surface = self.text_font.render('HAVE FUN', 
                    True, (0, 0, 0))
                screen.blit(text_surface, (200, 150))
            elif(self.collide_arec==3):
                screen.blit(self.chatbox, (185, 80))
                text_surface = self.text_font.render('TEXTBOOK', 
                    True, (0, 0, 0))
                screen.blit(text_surface, (225, 150))
            elif(self.collide_arec==4):
                screen.blit(self.chatbox, (240, 80))
                text_surface = self.text_font.render('EXPERIMENT', 
                    True, (0, 0, 0))
                screen.blit(text_surface, (280, 150))
            elif(self.collide_arec==5): ############### change from here
                self.mode='shelf'     ############### to here
            self.sprites_move.draw(screen)
  
            

############# Run Game ####################################
Game(800, 500).run()
