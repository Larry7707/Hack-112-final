import pygame


class Shelf(pygame.sprite.Sprite):
	def __init__(self, backGroundPic, windowW, windowH):
		super().__init__()
		self.background = pygame.image.load(backGroundPic).convert_alpha()
		self.background = pygame.transform.scale(self.background,
							 (int(windowW),int(windowH*0.8)))

	def display(self, screen):
		screen.blit(self.background, (0, 0))

class Basket(pygame.sprite.Sprite):
	def __init__(self, basketPic, windowW, windowH):
		super().__init__()
		self.basketBox = pygame.image.load(basketPic).convert_alpha()
		self.basketBox = pygame.transform.scale(self.basketBox,
							 (int(windowW),int(windowH*0.2)))

	def display(self, screen):
		screen.blit(self.basketBox, (0, int(screen.get_height()*0.8)))

class Bottle(pygame.sprite.Sprite):
	def __init__(self, bottlePic, windowW, windowH):
		self.bottle = pygame.image.load(bottlePic).convert_alpha()
		self.bottle = pygame.transform.scale(self.bottle, (40, 70))
		self.bottleSize = self.bottle.get_size()
		self.x = windowW*0.35
		self.y = windowH*0.8-85
		self.bottleRect = pygame.Rect(self.x, self.y,
		                              self.bottleSize[0], self.bottleSize[1])
	def update(self):
		self.bottleRect = pygame.Rect(self.x, self.y,
		                              self.bottleSize[0], self.bottleSize[1])

	def display(self, screen):
		screen.blit(self.bottle, (self.x, self.y))



def shelfRun(self,screen):
	# pygame.init()
	# mode = "shelf"
	# screen = pygame.display.set_mode((800, 500))
	# clock = pygame.time.Clock()

	shelf1 = Shelf("shelf.png", 800, 500)
	basket1 = Basket("basket.png", 800, 500)
	bottle1 = Bottle("bottle.png", 800,500)
	# initialX, initialY = bottle1.x, bottle1.y
	# playing = True

	# while (playing and mode == "shelf"):

		# clock.tick(50)
		# screen.fill((255, 255, 255))
	basket1.display(screen)
	shelf1.display(screen)
	bottle1.display(screen)

	for event in pygame.event.get():
		if event.type == pygame.MOUSEBUTTONDOWN:
			pos = pygame.mouse.get_pos()
			if bottle1.bottleRect.collidepoint(pos):
				if bottle1.x == 800*0.35:
					bottle1.x = 30
					bottle1.y = screen.get_height()*0.85
					# bottle1.update()
				elif bottle1.x == 30:
					bottle1.x = 800*0.35
					bottle1.y = 500*0.8-85
					# bottle1.update()
		elif event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				self.mode == "Main_Screen"

		# elif event.type == pygame.QUIT:
		# 	playing = False
	bottle1.update()
	pygame.display.flip()

	# pygame.quit()