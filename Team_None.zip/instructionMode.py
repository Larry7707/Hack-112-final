import pygame


class Instruction(pygame.sprite.Sprite):
	def __init__(self, canvasPic, instrTexts, windowW, windowH):
		super().__init__()
		self.background = pygame.image.load("canvasPic.png").convert_alpha()
		self.background = pygame.transform.scale(self.background,
							 (int(windowW*0.8),int(windowH*0.7)))
		#loading image creates a Surface
		bWidth = self.background.get_width() #size of the background
		bHeight = self.background.get_height()
		self.marginX, self.marginY = 0.1*windowW, 0.1*windowH
		text_font = pygame.font.SysFont("arial", 40)
		self.texts = []
		for i in range(len(instrTexts)):
			text = instrTexts[i]
			text_surface = text_font.render(text, True, (0, 0, 0)) #Surface
			text_rect = text_surface.get_rect(center=(windowW//2,
			                                          4*self.marginY+50*i))
			self.texts.append((text_surface, text_rect))


		button_font = pygame.font.SysFont("arial", 28)
		self.buttonText = button_font.render("  Back  ", True, (0, 0, 0),
												(153, 255, 153)) #Surface
		buttonSize = self.buttonText.get_size()
		self.buttonX = self.marginX+10 # left top coner of the button
		self.buttonY = self.marginY+bHeight-buttonSize[1]-10
		self.buttonRect = pygame.Rect(self.buttonX, self.buttonY,
								buttonSize[0], buttonSize[1])


	def display(self, screen):
		screen.blit(self.background, (self.marginX, self.marginY))
		#screen.blit(self.image, (self.buttonX, self.buttonY))
		screen.blit(self.buttonText, (self.buttonX, self.buttonY))
		for text in self.texts:
			screen.blit(text[0], text[1])



def instructionRun(self,screen):
	# pygame.init()
	# screen = pygame.display.set_mode((800, 500))
	# clock = pygame.time.Clock()

	instructionText = ["First step:", "get the right chemicals for the experiment"]
	instruction1 = Instruction('canvas.png', instructionText, 800, 500)

	# playing = True
	# mode = "instruction"
	# while (playing and mode == "instruction"):
		# clock.tick(50)
		# rectangles.update(500, 500)
		# screen.fill((255, 255, 255))
	instruction1.display(screen)
	for event in pygame.event.get():
		if event.type == pygame.MOUSEBUTTONDOWN:
			pos = pygame.mouse.get_pos()
			if instruction1.buttonRect.collidepoint(pos):
				self.mode = "Main_Screen"
					# screen.fill((255, 255, 255)) # THIS IS NOT CORRECT!!!
			# elif event.type == pygame.QUIT:
			# 	playing = False

	pygame.display.flip()
	# return mode
	# pygame.quit()
# instructionRun()