'''
Explosion.py

implements the Explosion class
Lukas Peraza, 2016 for 15-112 Pygame Lecture
'''
import pygame, random
from pygame.locals import *

class Character(pygame.sprite.Sprite):
    def __init__(self, data, pX, pY, cPicFilename, scale=1, angle=0):
        super(Character, self).__init__()
        self.cPositionX=pX
        self.cPositionY=pY
        # initialize and adjust the character
        self.character=pygame.image.load(cPicFilename).convert_alpha()    
        self.character=pygame.transform.rotate(self.character, angle)
        (cWidth, cHeight)=self.character.get_size()
        
        (self.cWidth, self.cHeight)=(int(cWidth*scale), int(cHeight*scale))
        self.image=pygame.transform.scale(self.character, (self.cWidth, self.cHeight))
        self.rect = pygame.Rect(self.cPositionX, self.cPositionY, self.cWidth, self.cWidth)
        (self.width, self.height)=(data.width, data.height)


    def getRect(self):  # GET REKT
        self.rect = pygame.Rect(self.cPositionX, self.cPositionY, self.cWidth, self.cHeight)

    def update(self, x, y):
        if(0 <= self.cPositionX+x <= self.width):
            self.cPositionX += x
        if(0 <= self.cPositionX+x <= self.height):
            self.cPositionY += y
        self.getRect()

class Background(object):
    def __init__(self, screen, width, height, bPicFilename):
        self.background=pygame.image.load(bPicFilename).convert()
        self.background=pygame.transform.scale(self.background, (width, height))
        self.screen=screen

    def display(self):
        self.screen.blit(self.background, (0,0))

