import pygame, random
from pygame.locals import *

class Struct(object): pass

data = Struct()
data.width, data.height=(600,600)

pygame.init()
screen = pygame.display.set_mode((data.width, data.height))
clock = pygame.time.Clock()


class Character(pygame.sprite.Sprite):
    def __init__(self, data, pX, pY, cPicFilename):
        super(Character, self).__init__()
        self.cPositionX=pX
        self.cPositionY=pY
        # initialize and adjust the character
        self.character=pygame.image.load(cPicFilename).convert_alpha()
        self.rect=pygame.transform.scale(self.character, (80, 80))
        self.image=pygame.transform.rotate(self.rect, 90)

    def display(self):
        screen.blit(self.character, (self.cPositionX,self.cPositionY))


    def update(self, x, y):
        if(0 <= self.cPositionX+x <= data.width):
            self.cPositionX += x
        if(0 <= self.cPositionX+x <= data.height):
            self.cPositionY += y


class Background(object):
    def __init__(self, data, bPicFilename):
        self.background=pygame.image.load(bPicFilename).convert()
        self.background=pygame.transform.scale(self.background, (data.width, data.height))

    def display(self):
        screen.blit(self.background, (0,0))


background = Background(data, 'pictures/background.jpg')
myCharacter = Character(data, 200, 200, 'pictures/fugu.png')

background.display()
sprites_move = pygame.sprite.Group()
#sprites_unmove = pygame.sprite.Group()  
sprites_move.add(myCharacter)


while True:
    for event in pygame.event.get():
        (moveX, moveY) = (0, 0)
        if event.type == QUIT:
            exit()
        if event.type == KEYDOWN:
            if event.key == K_LEFT:
                (moveX, moveY) = (-5, 0)
            elif event.key == K_RIGHT:
                (moveX, moveY) = (+5, 0)
            elif event.key == K_UP:
                (moveX, moveY) = (0, -5)
            elif event.key == K_DOWN:
                (moveX, moveY) = (0, +5)

    sprites_move.update(moveX,moveY)
    sprites_move.draw(screen)
    pygame.display.update()






